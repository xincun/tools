//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AdoAssist.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDD_ADOASSIST_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDS_ABOUTBOX                    131
#define IDD_DATAGRID_DIALOG             132
#define IDS_STRING132                   132
#define IDD_DIALOG1                     134
#define IDD_TABLEDATA_DIALOG            134
#define IDC_UDLDLG                      1000
#define IDC_EDIT1                       1001
#define IDC_COMBO_CNNSTRING              1001
#define IDC_DATAGRID                    1002
#define IDC_CURSORTYPE                  1003
#define IDC_EDIT_USER                   1004
#define IDC_LOCKTYPE                    1005
#define IDC_OPTIONS_RS                  1006
#define IDC_CONNECT                     1007
#define IDC_EDIT_PASSWORD               1008
#define IDC_EDIT_CONNECTPTR             1009
#define IDC_EDIT_RECORDSETPTR           1010
#define IDC_RECORDSET                   1011
#define IDC_EDIT_RECORDSETSQL           1012
#define IDC_EXCUTE                      1014
#define IDC_EDIT_EXCUTESQL              1015
#define IDC_CHECK_DATAGRIDSHOW          1016
#define IDC_OPTIONS_CMM                 1017
#define IDC_STATIC_SEPARAT              1018
#define IDC_STATIC_SEPARATE             1018
#define IDC_CHECK_TABLEDATASHOW         1018
#define IDC_OPENSCHEMA                  1019
#define IDC_DATAGRID1                   1019
#define IDC_TABLEDATA_LIST              1020
#define IDC_QUERYTYPE                   1021
#define IDC_BUTTON1                     1021
#define IDC_WRITECODE                   1021
#define IDC_COMBO1                      1022
#define IDC_CODETYPE                    1022
#define IDC_COMBO_SHOWTYPE              1022
#define IDC_CHECK_INDEX                 1023
#define IDC_NEXTRECORDSET               1024
#define IDC_STATIC_LOCATION             1025
#define IDC_STATIC_G                    1026
#define IDC_COMBO2                      1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
