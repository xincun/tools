﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AdmiralDebilitate
{
    public partial class About : Form
    {
        public About()
        {
            InitializeComponent();
        }

        private void About_Load(object sender, EventArgs e)
        {
            DateTime fileDate = new System.IO.FileInfo(Application.ExecutablePath).LastWriteTime;
            System.Diagnostics.FileVersionInfo fileVersion = System.Diagnostics.FileVersionInfo.GetVersionInfo(Application.ExecutablePath);

            AppTitle.Text = "AdmiralDebilitate " + fileVersion.ProductMajorPart + "." + fileVersion.ProductMinorPart;
            Author.Text = "Greg Jenkins, " + fileDate.ToString("MMMM yyyy");
        }
    }
}
