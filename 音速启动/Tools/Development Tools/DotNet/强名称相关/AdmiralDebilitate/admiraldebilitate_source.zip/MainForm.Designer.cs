﻿namespace AdmiralDebilitate
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImageList = new System.Windows.Forms.ImageList(this.components);
            this.LoadModulesWorker = new System.ComponentModel.BackgroundWorker();
            this.StatusStrip = new System.Windows.Forms.StatusStrip();
            this.SBProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.SBLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.SBCancel = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.Tree = new System.Windows.Forms.TreeView();
            this.TreeMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.RemoveStrongNameSigningToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.lblDetails = new System.Windows.Forms.Label();
            this.AssemblySummary = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lstProblems = new System.Windows.Forms.ListBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.label1 = new System.Windows.Forms.Label();
            this.lstMarkedAssemblies = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lstIndirectlyMarkedAssemblies = new System.Windows.Forms.ListBox();
            this.cmdMarkAll = new System.Windows.Forms.Button();
            this.cmdUndo = new System.Windows.Forms.Button();
            this.cmdApply = new System.Windows.Forms.Button();
            this.cmdClear = new System.Windows.Forms.Button();
            this.chkCreateBackups = new System.Windows.Forms.CheckBox();
            this.UpdateMarkBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.ApplyPatchesWorker = new System.ComponentModel.BackgroundWorker();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.MenuStrip.SuspendLayout();
            this.StatusStrip.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.TreeMenu.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.SuspendLayout();
            // 
            // MenuStrip
            // 
            this.MenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.MenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip.Name = "MenuStrip";
            this.MenuStrip.Size = new System.Drawing.Size(906, 24);
            this.MenuStrip.TabIndex = 0;
            this.MenuStrip.Text = "MenuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "&Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(100, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // ImageList
            // 
            this.ImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ImageList.ImageStream")));
            this.ImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.ImageList.Images.SetKeyName(0, "app");
            this.ImageList.Images.SetKeyName(1, "dll");
            this.ImageList.Images.SetKeyName(2, "lock");
            this.ImageList.Images.SetKeyName(3, "unlock");
            // 
            // LoadModulesWorker
            // 
            this.LoadModulesWorker.WorkerReportsProgress = true;
            this.LoadModulesWorker.WorkerSupportsCancellation = true;
            this.LoadModulesWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.LoadModulesWorker_DoWork);
            this.LoadModulesWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.LoadModulesWorker_RunWorkerCompleted);
            this.LoadModulesWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.LoadModulesWorker_ProgressChanged);
            // 
            // StatusStrip
            // 
            this.StatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SBProgress,
            this.SBLabel,
            this.SBCancel});
            this.StatusStrip.Location = new System.Drawing.Point(0, 562);
            this.StatusStrip.Name = "StatusStrip";
            this.StatusStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.StatusStrip.Size = new System.Drawing.Size(906, 22);
            this.StatusStrip.TabIndex = 2;
            this.StatusStrip.Text = "StatusStrip";
            // 
            // SBProgress
            // 
            this.SBProgress.Name = "SBProgress";
            this.SBProgress.Size = new System.Drawing.Size(100, 16);
            this.SBProgress.Step = 1;
            this.SBProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            // 
            // SBLabel
            // 
            this.SBLabel.Name = "SBLabel";
            this.SBLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // SBCancel
            // 
            this.SBCancel.IsLink = true;
            this.SBCancel.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline;
            this.SBCancel.Name = "SBCancel";
            this.SBCancel.Size = new System.Drawing.Size(43, 17);
            this.SBCancel.Text = "Cancel";
            this.SBCancel.Visible = false;
            this.SBCancel.VisitedLinkColor = System.Drawing.Color.Blue;
            this.SBCancel.Click += new System.EventHandler(this.SBCancel_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.Tree);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(906, 538);
            this.splitContainer1.SplitterDistance = 326;
            this.splitContainer1.TabIndex = 3;
            // 
            // Tree
            // 
            this.Tree.ContextMenuStrip = this.TreeMenu;
            this.Tree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tree.HideSelection = false;
            this.Tree.ImageKey = "app";
            this.Tree.ImageList = this.ImageList;
            this.Tree.Location = new System.Drawing.Point(0, 0);
            this.Tree.Name = "Tree";
            this.Tree.SelectedImageIndex = 0;
            this.Tree.ShowLines = false;
            this.Tree.Size = new System.Drawing.Size(326, 538);
            this.Tree.TabIndex = 2;
            this.Tree.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Tree_AfterSelect);
            this.Tree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Tree_MouseDown);
            // 
            // TreeMenu
            // 
            this.TreeMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RemoveStrongNameSigningToolStripMenuItem});
            this.TreeMenu.Name = "TreeMenu";
            this.TreeMenu.Size = new System.Drawing.Size(149, 26);
            this.TreeMenu.Opening += new System.ComponentModel.CancelEventHandler(this.TreeMenu_Opening);
            // 
            // RemoveStrongNameSigningToolStripMenuItem
            // 
            this.RemoveStrongNameSigningToolStripMenuItem.Name = "RemoveStrongNameSigningToolStripMenuItem";
            this.RemoveStrongNameSigningToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.RemoveStrongNameSigningToolStripMenuItem.Text = "&Mark/Unmark";
            this.RemoveStrongNameSigningToolStripMenuItem.Click += new System.EventHandler(this.MarkOrUnmarkToolStripMenuItem_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.cmdMarkAll);
            this.splitContainer2.Panel2.Controls.Add(this.cmdUndo);
            this.splitContainer2.Panel2.Controls.Add(this.cmdApply);
            this.splitContainer2.Panel2.Controls.Add(this.cmdClear);
            this.splitContainer2.Panel2.Controls.Add(this.chkCreateBackups);
            this.splitContainer2.Size = new System.Drawing.Size(576, 538);
            this.splitContainer2.SplitterDistance = 468;
            this.splitContainer2.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.splitContainer5);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(576, 468);
            this.splitContainer3.SplitterDistance = 179;
            this.splitContainer3.TabIndex = 1;
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.lblDetails);
            this.splitContainer5.Panel1.Controls.Add(this.AssemblySummary);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.label3);
            this.splitContainer5.Panel2.Controls.Add(this.lstProblems);
            this.splitContainer5.Size = new System.Drawing.Size(576, 179);
            this.splitContainer5.SplitterDistance = 210;
            this.splitContainer5.TabIndex = 0;
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblDetails.Location = new System.Drawing.Point(0, 0);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(89, 13);
            this.lblDetails.TabIndex = 3;
            this.lblDetails.Text = "Assembly Details:";
            // 
            // AssemblySummary
            // 
            this.AssemblySummary.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.AssemblySummary.BackColor = System.Drawing.SystemColors.Control;
            this.AssemblySummary.FormattingEnabled = true;
            this.AssemblySummary.Location = new System.Drawing.Point(1, 16);
            this.AssemblySummary.Name = "AssemblySummary";
            this.AssemblySummary.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.AssemblySummary.Size = new System.Drawing.Size(207, 160);
            this.AssemblySummary.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Problem Areas:";
            // 
            // lstProblems
            // 
            this.lstProblems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstProblems.BackColor = System.Drawing.SystemColors.Control;
            this.lstProblems.FormattingEnabled = true;
            this.lstProblems.HorizontalScrollbar = true;
            this.lstProblems.Location = new System.Drawing.Point(3, 17);
            this.lstProblems.Name = "lstProblems";
            this.lstProblems.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.lstProblems.Size = new System.Drawing.Size(356, 160);
            this.lstProblems.TabIndex = 2;
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.label1);
            this.splitContainer4.Panel1.Controls.Add(this.lstMarkedAssemblies);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.label2);
            this.splitContainer4.Panel2.Controls.Add(this.lstIndirectlyMarkedAssemblies);
            this.splitContainer4.Size = new System.Drawing.Size(576, 285);
            this.splitContainer4.SplitterDistance = 297;
            this.splitContainer4.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Marked Assemblies:";
            // 
            // lstMarkedAssemblies
            // 
            this.lstMarkedAssemblies.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstMarkedAssemblies.BackColor = System.Drawing.SystemColors.Control;
            this.lstMarkedAssemblies.FormattingEnabled = true;
            this.lstMarkedAssemblies.Location = new System.Drawing.Point(2, 16);
            this.lstMarkedAssemblies.Name = "lstMarkedAssemblies";
            this.lstMarkedAssemblies.Size = new System.Drawing.Size(292, 251);
            this.lstMarkedAssemblies.Sorted = true;
            this.lstMarkedAssemblies.TabIndex = 3;
            this.lstMarkedAssemblies.SelectedIndexChanged += new System.EventHandler(this.lstMarkedAssemblies_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Indirectly Marked Assemblies:";
            // 
            // lstIndirectlyMarkedAssemblies
            // 
            this.lstIndirectlyMarkedAssemblies.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstIndirectlyMarkedAssemblies.BackColor = System.Drawing.SystemColors.Control;
            this.lstIndirectlyMarkedAssemblies.FormattingEnabled = true;
            this.lstIndirectlyMarkedAssemblies.Location = new System.Drawing.Point(3, 16);
            this.lstIndirectlyMarkedAssemblies.Name = "lstIndirectlyMarkedAssemblies";
            this.lstIndirectlyMarkedAssemblies.Size = new System.Drawing.Size(269, 251);
            this.lstIndirectlyMarkedAssemblies.Sorted = true;
            this.lstIndirectlyMarkedAssemblies.TabIndex = 3;
            this.lstIndirectlyMarkedAssemblies.SelectedIndexChanged += new System.EventHandler(this.lstIndirectlyMarkedAssemblies_SelectedIndexChanged);
            // 
            // cmdMarkAll
            // 
            this.cmdMarkAll.Location = new System.Drawing.Point(95, 23);
            this.cmdMarkAll.Name = "cmdMarkAll";
            this.cmdMarkAll.Size = new System.Drawing.Size(79, 40);
            this.cmdMarkAll.TabIndex = 3;
            this.cmdMarkAll.Text = "Mark All";
            this.cmdMarkAll.UseVisualStyleBackColor = true;
            this.cmdMarkAll.Click += new System.EventHandler(this.cmdMarkAll_Click);
            // 
            // cmdUndo
            // 
            this.cmdUndo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdUndo.Location = new System.Drawing.Point(368, 23);
            this.cmdUndo.Name = "cmdUndo";
            this.cmdUndo.Size = new System.Drawing.Size(98, 40);
            this.cmdUndo.TabIndex = 2;
            this.cmdUndo.Text = "Undo Changes";
            this.cmdUndo.UseVisualStyleBackColor = true;
            this.cmdUndo.Click += new System.EventHandler(this.cmdUndo_Click);
            // 
            // cmdApply
            // 
            this.cmdApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdApply.Location = new System.Drawing.Point(472, 23);
            this.cmdApply.Name = "cmdApply";
            this.cmdApply.Size = new System.Drawing.Size(101, 40);
            this.cmdApply.TabIndex = 2;
            this.cmdApply.Text = "Apply Changes";
            this.cmdApply.UseVisualStyleBackColor = true;
            this.cmdApply.Click += new System.EventHandler(this.cmdApply_Click);
            // 
            // cmdClear
            // 
            this.cmdClear.Location = new System.Drawing.Point(10, 23);
            this.cmdClear.Name = "cmdClear";
            this.cmdClear.Size = new System.Drawing.Size(79, 40);
            this.cmdClear.TabIndex = 1;
            this.cmdClear.Text = "Clear All";
            this.cmdClear.UseVisualStyleBackColor = true;
            this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
            // 
            // chkCreateBackups
            // 
            this.chkCreateBackups.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkCreateBackups.AutoSize = true;
            this.chkCreateBackups.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkCreateBackups.Checked = true;
            this.chkCreateBackups.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCreateBackups.Location = new System.Drawing.Point(472, 3);
            this.chkCreateBackups.Name = "chkCreateBackups";
            this.chkCreateBackups.Size = new System.Drawing.Size(101, 17);
            this.chkCreateBackups.TabIndex = 0;
            this.chkCreateBackups.Text = "Create backups";
            this.chkCreateBackups.UseVisualStyleBackColor = true;
            // 
            // UpdateMarkBackgroundWorker
            // 
            this.UpdateMarkBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.UpdateMarkBackgroundWorker_DoWork);
            this.UpdateMarkBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.UpdateMarkBackgroundWorker_RunWorkerCompleted);
            // 
            // ApplyPatchesWorker
            // 
            this.ApplyPatchesWorker.WorkerReportsProgress = true;
            this.ApplyPatchesWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ApplyPatchesWorker_DoWork);
            this.ApplyPatchesWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.ApplyPatchesWorker_RunWorkerCompleted);
            this.ApplyPatchesWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.ApplyPatchesWorker_ProgressChanged);
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.Filter = "Executable Files (*.exe)|*.exe|DLL Files (*.dll)|*.dll|All Executable Files (*.ex" +
                "e, *.dll)|*.exe;*.dll|All Files (*.*)|*.*";
            this.OpenFileDialog.InitialDirectory = global::AdmiralDebilitate.Properties.Settings.Default.InitialDirectory;
            this.OpenFileDialog.Multiselect = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(906, 584);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.StatusStrip);
            this.Controls.Add(this.MenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.MenuStrip;
            this.Name = "MainForm";
            this.Text = "AdmiralDebilitate";
            this.MenuStrip.ResumeLayout(false);
            this.MenuStrip.PerformLayout();
            this.StatusStrip.ResumeLayout(false);
            this.StatusStrip.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.TreeMenu.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.Panel2.PerformLayout();
            this.splitContainer5.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            this.splitContainer4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.ComponentModel.BackgroundWorker LoadModulesWorker;
        private System.Windows.Forms.StatusStrip StatusStrip;
        private System.Windows.Forms.ToolStripProgressBar SBProgress;
        private System.Windows.Forms.ToolStripStatusLabel SBLabel;
        private System.Windows.Forms.ImageList ImageList;
        private System.Windows.Forms.ToolStripStatusLabel SBCancel;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView Tree;
        private System.Windows.Forms.ContextMenuStrip TreeMenu;
        private System.Windows.Forms.ToolStripMenuItem RemoveStrongNameSigningToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker UpdateMarkBackgroundWorker;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstMarkedAssemblies;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lstIndirectlyMarkedAssemblies;
        private System.Windows.Forms.Button cmdApply;
        private System.Windows.Forms.Button cmdClear;
        private System.Windows.Forms.CheckBox chkCreateBackups;
        private System.ComponentModel.BackgroundWorker ApplyPatchesWorker;
        private System.Windows.Forms.Button cmdMarkAll;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.ListBox AssemblySummary;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lstProblems;
        private System.Windows.Forms.Button cmdUndo;
    }
}

