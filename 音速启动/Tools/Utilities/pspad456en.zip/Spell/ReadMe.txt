Extract Dictionary files here
-----------------------------

1. - go to http://www.pspad.com/
2. -- choose your favorite language
3. ---- go to Download
4. ------ go to "Spell check dictionaries"
5. -------- download your favorite spellcheck dictionaries
6. - After downloading, unpack and save the file here in this directory
7. Then, go to the menu "Settings/Spell settings..." and select one of the installed dictionaries.
8. Then use "Tools/Spell Check" or press [F7]

Happy PSPading ;-)
