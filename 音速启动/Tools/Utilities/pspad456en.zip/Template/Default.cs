using System;
using System.Collections.Generic;
using System.Text;

namespace GoogleRequester
{
    public class Class1
    {

        #region Private Fields

        #endregion

        #region Properties

        #endregion

    }
}
